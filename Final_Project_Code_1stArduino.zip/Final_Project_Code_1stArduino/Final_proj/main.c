/*
 * Final_Project.c
 *
 * Created: 9/21/2021 21:21:21 AM
 * Author : Zeyu Niu
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include "ST7735.h"
#include "LCD_GFX.h"
#include <stdio.h>
#include "uart.h"
#include <avr/interrupt.h>
#include <avr/delay.h>
#include <math.h>

//Serial Parameters
#define BAUD_RATE 9600
#define BAUD_PRESCALER (((F_CPU / (BAUD_RATE * 16UL))) - 1)

/******************************************************************************
* Global Functions
******************************************************************************/
uint8_t sys_start = 0;			//0 for screen cleaning, 1 for start game, 2 for game end
char String[40];
volatile int X = 25;			//Real duty cycle
volatile int D = 95;


void Serial_Ini()
{
	UART_init(BAUD_PRESCALER);
}

 void Timer0_Ini()
 {
	 //pre-scale the timer0 to 1/256
	 TCCR0B &= ~(1<<CS00);
	 TCCR0B &= ~(1<<CS01);
	 TCCR0B |= (1<<CS02);

	 //Set the Fast PWM mode
	 TCCR0A |= (1<<WGM00);
	 TCCR0A |= (1<<WGM01);
	 TCCR0B &= ~(1<<WGM02);
	 OCR0B = (256*D/100 - 1);

	 // toggle OC0B on compare match
	 TCCR0A |= (1<<COM0B0);
	 TCCR0A |= (1<<COM0B1);
 }

void LCD_Initialize()
{
	lcd_init();
	LCD_setScreen(BLACK);
	LCD_drawCircle(120,110,5,WHITE);
	LCD_drawBlock(123,107,123,22,WHITE);
	LCD_drawBlock(117,107,123,22,WHITE);
	LCD_drawBall(120,110,4,RED);
	//Draw_Paddle();
}

void IO_Ini()
{
	DDRD &= ~(1<<DDD2);				//set PD2 as input (Wifi_Down)
	DDRD |= (1<<DDD2);				//set PD2 as output (yellow)
 	DDRD |= (1<<DDD2);				//set PD3 as output (red)
	//DDRD |= (1<<DDD5);				//set PD5 as output (PWM)
	DDRB |= (1<<DDB4);				//set PD5 as output (green)	
	DDRD |= (1<<DDD7);				//set PD6 as output (buzzer)
	
	PORTD &= ~(1 << PORTD2);		//set PD2 low (Yellow LED)
	PORTD &= ~(1 << PORTD3);		//set PD3 low 
	PORTB &= ~(1 << PORTB4);		//set PD5 low (Player LED)
	PORTD &= ~(1 << PORTD4);		//set PD4 low (PC LED)
	PORTD |= (1 << PORTD7);			//set PD7 high (buzzer)

	//DDRB |= (1 << DDB5);			//set PB5 as output
	//PORTD &= ~(1 << PORTD7);			//Drive PD7 as low (buzzer)
}

void ADC_Ini()
{
	//clear power reduction for ADC
	PRR &= (1<<PRADC);
	//Vref = ADC
	ADMUX |= (1<<REFS0);
	ADMUX &= ~(1<<REFS1);
	//Set the ADC clock: divided by 128
	ADCSRA |= (1<<ADPS0);
	ADCSRA |= (1<<ADPS1);
	ADCSRA |= (1<<ADPS2);
	//select channel 0
	ADMUX &= ~(1<<MUX0);
	ADMUX &= ~(1<<MUX1);
	ADMUX &= ~(1<<MUX2);
	ADMUX &= ~(1<<MUX3);
	//Set to free running
	ADCSRA |= (1<<ADATE);		//auto triggering of adc
	ADCSRB &= ~(1<<ADTS0);		//free running mode ADT[2:0] = 000
	ADCSRB &= ~(1<<ADTS1);
	ADCSRB &= ~(1<<ADTS2);
	//disable digital input buffer
	DIDR0 |= (1<<ADC0D);
	//Enable ADC
	ADCSRA |= (1<<ADEN);
	//Enable ADC interrupt
	ADCSRA |= (1<<ADIE);
	//start conversation
	ADCSRA |= (1<<ADSC);
	
}

ISR(ADC_vect)
{
	int temp_cel = ((int)(5*(ADC-5)-500)/10);
	
	sprintf(String, "Real-time Temperature: %d Celsius\n,",temp_cel);
	UART_putstring(String);
	
	sprintf(String, "ADC: %d\n",ADC);
	UART_putstring(String);
	
	if ((temp_cel<=75)&&(temp_cel>=0))
	{
		X=100*temp_cel/75;
		D = 100-X;
	}
	else if(temp_cel>75)
	{
		X=5;
		D = 100-X;
	}
	else
	{
		X=20;
		D = 100-X;
	}
	OCR0B = (256*D/100 - 1);
	
	//Call the function that controls the LED lights and buzzer 
	ADC_CONTROL();
}


void Initialize()
{
	cli();
	IO_Ini();
	Serial_Ini();
	Timer0_Ini();
	ADC_Ini();
	LCD_Initialize();
	sei();
}

void ADC_CONTROL()
{
	int temp_cel = ((int)(5*(ADC-5)-500)/10);		//Real time Celsius temperature value
	uint8_t height = 116 - temp_cel;		//Height of the thermometer
	
	char tempL = (temp_cel%10) + 0x30;		//int to ASCII
	char tempH = (temp_cel/10) + 0x30;		//int to ASCII
		
	if (ADC<205)
	{
		//indicate the temp status
		LCD_drawString(40,51,"Nice Temp!", GREEN,WHITE);		
		
		//Display Real-time Temp (Celsius)
		LCD_drawString(35,30,"Celsius:", BLUE,YELLOW);	
		LCD_drawChar(80,30,tempH,BLUE,YELLOW);	
		LCD_drawBlock(85,30,86,37, YELLOW);	
		LCD_drawChar(87,30,tempL,BLUE,YELLOW);
		
		//Visualized Thermometer
		LCD_drawBlock(118,height,122,107,GREEN);
		//LCD_drawBlock(118,68,122,height,WHITE);	
		LCD_drawBlock(118,26,122,height,WHITE);			
		
		//set LED indicators
		PORTB |= (1 << PORTB4);			//set PD5(green LED) high
		PORTD &= ~(1 << PORTD3);		//set PB4 low
		PORTD &= ~(1 << PORTD2);		//yellow LED off		
		
		//Buzzer_high();
	}
	
	if (ADC>205 && ADC<245)
	{
		//indicate the temp status
		LCD_drawString(40,51, "Caution!  ", BLUE ,WHITE);
		
		//Display Real-time Temp (Celsius)
		LCD_drawString(35,30,"Celsius:", BLUE,YELLOW);
		LCD_drawChar(80,30,tempH,BLUE,YELLOW);
		LCD_drawBlock(85,30,86,37, YELLOW);
		LCD_drawChar(87,30,tempL,BLUE,YELLOW);
		
		//Visualized Thermometer
		LCD_drawBlock(118,height,122,107,YELLOW);
		LCD_drawBlock(118,26,122,46,WHITE);

		//set LED indicators
		PORTD |= (1 << PORTD2);			//yellow LED on
		PORTD &= ~(1 << PORTD3);		//set PB3 low
		PORTB &= ~(1 << PORTB4);		//set PB5 low
			
		Buzzer_med();
		
	}
	
	if (ADC>245)
	{
		//Send the indicate message and a visualized thermometer via LCD Screen
		LCD_drawString(40,51, "Cool Down!", RED,WHITE);
		
		//Display Real-time Temp (Celsius)
		LCD_drawString(35,30,"Celsius:", BLUE,YELLOW);
		LCD_drawChar(80,30,tempH,BLUE,YELLOW);
		LCD_drawBlock(85,30,86,37, YELLOW);
		LCD_drawChar(87,30,tempL,BLUE,YELLOW);
		
		//Visualized Thermometer
		LCD_drawBlock(118,height,122,107,RED);

		//set LED indicators
		PORTD |= (1 << PORTD3);			//set PD3(red LED) high
		PORTB &= ~(1 << PORTB4);		//set PB5 low
		PORTD &= ~(1 << PORTD2);		//yellow LED off
		
		Buzzer_high();
	}
	
}


int main(void)
{
	Initialize();
	while(1)
	{
				
		if(sys_start == 0)
			{
				sys_start = 1;
			}
			
			else if (sys_start == 1)
			{
				sys_start = 0;		
			}			
	}	
}

